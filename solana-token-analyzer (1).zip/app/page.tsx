"use client"

import { useState, useEffect } from "react"
import { Search, AlertTriangle, Shield, Eye, Wallet, Users } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription } from "@/components/ui/alert"

// Mock data - in real implementation, this would come from APIs
const mockTokenData = {
  address: "7GCihgDB8fe6KNjn2MYtkzZcRjQy3t9GHdC8uHYmW2hr",
  name: "Popcat",
  symbol: "POPCAT",
  price: 1.23,
  marketCap: 1234567890,
  volume24h: 12345678,
  holders: 45678,
  rugScore: 15, // Lower is better
  freshWallets: 23,
  snipers: 5,
  bundleWallets: 8,
  liquidity: 5678900,
  createdAt: "2024-01-15T10:30:00Z",
  creator: "9WzDXwBbmkg8ZTbNMqUxvQRAyrZzDsGYdLVL9zYtAWWM",
  verified: false,
  freezeAuthority: null,
  mintAuthority: null,
  topHolders: [
    { address: "ABC...123", percentage: 12.5, isSniper: true, isFresh: false },
    { address: "DEF...456", percentage: 8.3, isSniper: false, isFresh: true },
    { address: "GHI...789", percentage: 6.7, isSniper: false, isFresh: false },
  ],
}

export default function SolanaTokenAnalyzer() {
  const [searchQuery, setSearchQuery] = useState("")
  const [tokenData, setTokenData] = useState(null)
  const [loading, setLoading] = useState(false)
  const [lastUpdated, setLastUpdated] = useState(new Date())

  const handleSearch = async () => {
    if (!searchQuery.trim()) return

    setLoading(true)
    // Simulate API call delay
    setTimeout(() => {
      setTokenData(mockTokenData)
      setLoading(false)
      setLastUpdated(new Date())
    }, 1500)
  }

  const getRugScoreColor = (score) => {
    if (score < 20) return "text-green-500"
    if (score < 50) return "text-yellow-500"
    return "text-red-500"
  }

  const getRugScoreLabel = (score) => {
    if (score < 20) return "Low Risk"
    if (score < 50) return "Medium Risk"
    return "High Risk"
  }

  useEffect(() => {
    // Auto-refresh every 30 seconds when token is loaded
    if (tokenData) {
      const interval = setInterval(() => {
        setLastUpdated(new Date())
        // In real app, would refetch data here
      }, 30000)
      return () => clearInterval(interval)
    }
  }, [tokenData])

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">Solana Token Analyzer</h1>
          <p className="text-slate-300">Advanced token analysis with rug check, sniper detection, and more</p>
        </div>

        {/* Search */}
        <div className="max-w-2xl mx-auto mb-8">
          <div className="flex gap-2">
            <Input
              placeholder="Enter token address or symbol..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyPress={(e) => e.key === "Enter" && handleSearch()}
              className="bg-slate-800 border-slate-700 text-white placeholder:text-slate-400"
            />
            <Button onClick={handleSearch} disabled={loading} className="bg-purple-600 hover:bg-purple-700">
              <Search className="w-4 h-4 mr-2" />
              {loading ? "Analyzing..." : "Analyze"}
            </Button>
          </div>
        </div>

        {/* Results */}
        {tokenData && (
          <div className="space-y-6">
            {/* Token Overview */}
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-white text-2xl">
                      {tokenData.name} ({tokenData.symbol})
                    </CardTitle>
                    <CardDescription className="text-slate-400 font-mono text-sm">{tokenData.address}</CardDescription>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold text-white">${tokenData.price}</div>
                    <div className="text-sm text-slate-400">Last updated: {lastUpdated.toLocaleTimeString()}</div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div>
                    <div className="text-slate-400 text-sm">Market Cap</div>
                    <div className="text-white font-semibold">${(tokenData.marketCap / 1000000).toFixed(2)}M</div>
                  </div>
                  <div>
                    <div className="text-slate-400 text-sm">24h Volume</div>
                    <div className="text-white font-semibold">${(tokenData.volume24h / 1000000).toFixed(2)}M</div>
                  </div>
                  <div>
                    <div className="text-slate-400 text-sm">Holders</div>
                    <div className="text-white font-semibold">{tokenData.holders.toLocaleString()}</div>
                  </div>
                  <div>
                    <div className="text-slate-400 text-sm">Liquidity</div>
                    <div className="text-white font-semibold">${(tokenData.liquidity / 1000000).toFixed(2)}M</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Security Analysis */}
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Shield className="w-5 h-5" />
                  Security Analysis
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                  <div className="bg-slate-700 p-4 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <AlertTriangle className={`w-5 h-5 ${getRugScoreColor(tokenData.rugScore)}`} />
                      <span className="text-white font-semibold">Rug Score</span>
                    </div>
                    <div className={`text-2xl font-bold ${getRugScoreColor(tokenData.rugScore)}`}>
                      {tokenData.rugScore}/100
                    </div>
                    <div className="text-sm text-slate-400">{getRugScoreLabel(tokenData.rugScore)}</div>
                    <Progress value={tokenData.rugScore} className="mt-2" />
                  </div>

                  <div className="bg-slate-700 p-4 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <Users className="w-5 h-5 text-yellow-500" />
                      <span className="text-white font-semibold">Fresh Wallets</span>
                    </div>
                    <div className="text-2xl font-bold text-yellow-500">{tokenData.freshWallets}</div>
                    <div className="text-sm text-slate-400">New holders {"<"} 24h</div>
                  </div>

                  <div className="bg-slate-700 p-4 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <Eye className="w-5 h-5 text-red-500" />
                      <span className="text-white font-semibold">Snipers</span>
                    </div>
                    <div className="text-2xl font-bold text-red-500">{tokenData.snipers}</div>
                    <div className="text-sm text-slate-400">Detected snipers</div>
                  </div>

                  <div className="bg-slate-700 p-4 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <Wallet className="w-5 h-5 text-orange-500" />
                      <span className="text-white font-semibold">Bundle Wallets</span>
                    </div>
                    <div className="text-2xl font-bold text-orange-500">{tokenData.bundleWallets}</div>
                    <div className="text-sm text-slate-400">Coordinated wallets</div>
                  </div>
                </div>

                {/* Security Alerts */}
                <div className="space-y-2">
                  {tokenData.rugScore > 50 && (
                    <Alert className="border-red-500 bg-red-500/10">
                      <AlertTriangle className="h-4 w-4 text-red-500" />
                      <AlertDescription className="text-red-400">
                        High rug risk detected. Exercise extreme caution.
                      </AlertDescription>
                    </Alert>
                  )}
                  {tokenData.snipers > 3 && (
                    <Alert className="border-yellow-500 bg-yellow-500/10">
                      <Eye className="h-4 w-4 text-yellow-500" />
                      <AlertDescription className="text-yellow-400">
                        Multiple snipers detected in early transactions.
                      </AlertDescription>
                    </Alert>
                  )}
                  {!tokenData.mintAuthority && !tokenData.freezeAuthority && (
                    <Alert className="border-green-500 bg-green-500/10">
                      <Shield className="h-4 w-4 text-green-500" />
                      <AlertDescription className="text-green-400">
                        Mint and freeze authority renounced - Good sign!
                      </AlertDescription>
                    </Alert>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Detailed Analysis Tabs */}
            <Tabs defaultValue="holders" className="w-full">
              <TabsList className="grid w-full grid-cols-4 bg-slate-800">
                <TabsTrigger value="holders" className="text-white data-[state=active]:bg-purple-600">
                  Top Holders
                </TabsTrigger>
                <TabsTrigger value="trading" className="text-white data-[state=active]:bg-purple-600">
                  Trading Data
                </TabsTrigger>
                <TabsTrigger value="security" className="text-white data-[state=active]:bg-purple-600">
                  Security Details
                </TabsTrigger>
                <TabsTrigger value="sources" className="text-white data-[state=active]:bg-purple-600">
                  Data Sources
                </TabsTrigger>
              </TabsList>

              <TabsContent value="holders" className="space-y-4">
                <Card className="bg-slate-800 border-slate-700">
                  <CardHeader>
                    <CardTitle className="text-white">Top Holders Analysis</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {tokenData.topHolders.map((holder, index) => (
                        <div key={index} className="flex items-center justify-between p-3 bg-slate-700 rounded-lg">
                          <div className="flex items-center gap-3">
                            <div className="text-white font-mono">{holder.address}</div>
                            <div className="flex gap-1">
                              {holder.isSniper && (
                                <Badge variant="destructive" className="text-xs">
                                  Sniper
                                </Badge>
                              )}
                              {holder.isFresh && (
                                <Badge variant="secondary" className="text-xs">
                                  Fresh
                                </Badge>
                              )}
                            </div>
                          </div>
                          <div className="text-white font-semibold">{holder.percentage}%</div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="trading" className="space-y-4">
                <Card className="bg-slate-800 border-slate-700">
                  <CardHeader>
                    <CardTitle className="text-white">Trading Information</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                      <div>
                        <div className="text-slate-400 text-sm">DEX</div>
                        <div className="text-white font-semibold">Raydium</div>
                      </div>
                      <div>
                        <div className="text-slate-400 text-sm">Pool Created</div>
                        <div className="text-white font-semibold">
                          {new Date(tokenData.createdAt).toLocaleDateString()}
                        </div>
                      </div>
                      <div>
                        <div className="text-slate-400 text-sm">Creator</div>
                        <div className="text-white font-mono text-sm">{tokenData.creator.slice(0, 8)}...</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="security" className="space-y-4">
                <Card className="bg-slate-800 border-slate-700">
                  <CardHeader>
                    <CardTitle className="text-white">Security Details</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <div className="text-slate-400 text-sm">Mint Authority</div>
                          <div className="text-white">{tokenData.mintAuthority ? "Active" : "Renounced ✓"}</div>
                        </div>
                        <div>
                          <div className="text-slate-400 text-sm">Freeze Authority</div>
                          <div className="text-white">{tokenData.freezeAuthority ? "Active" : "Renounced ✓"}</div>
                        </div>
                      </div>
                      <div>
                        <div className="text-slate-400 text-sm">Verification Status</div>
                        <div className="text-white">{tokenData.verified ? "Verified ✓" : "Not Verified"}</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="sources" className="space-y-4">
                <Card className="bg-slate-800 border-slate-700">
                  <CardHeader>
                    <CardTitle className="text-white">Data Sources</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div className="text-center p-4 bg-slate-700 rounded-lg">
                        <div className="text-white font-semibold">Solscan</div>
                        <div className="text-green-400 text-sm">✓ Connected</div>
                      </div>
                      <div className="text-center p-4 bg-slate-700 rounded-lg">
                        <div className="text-white font-semibold">Birdseye</div>
                        <div className="text-green-400 text-sm">✓ Connected</div>
                      </div>
                      <div className="text-center p-4 bg-slate-700 rounded-lg">
                        <div className="text-white font-semibold">Raydium</div>
                        <div className="text-green-400 text-sm">✓ Connected</div>
                      </div>
                      <div className="text-center p-4 bg-slate-700 rounded-lg">
                        <div className="text-white font-semibold">Pump.fun</div>
                        <div className="text-green-400 text-sm">✓ Connected</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        )}

        {/* Footer */}
        <div className="text-center mt-12 text-slate-400 text-sm">
          <p>Data aggregated from Solscan, Birdseye, Raydium, and Pump.fun APIs</p>
          <p>Always DYOR (Do Your Own Research) before investing</p>
        </div>
      </div>
    </div>
  )
}
